import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-global-aside',
  templateUrl: './global-aside.component.html',
  styleUrls: ['./global-aside.component.less']
})
export class GlobalAsideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
